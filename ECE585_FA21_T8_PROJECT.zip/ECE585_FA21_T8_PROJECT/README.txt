TEAM 8 - JONATHAN S, DANG N, RONALDO L
ECE585 FA21 
FINAL PROJECT

We implemented our project code in C.

Marks_traces_and_outputs
-Folder contains the traces t0.trace through t13.trace that
Professor Mark Faust gave to us during the DEMO from his flash drive.
It also contains the t0.out through t13.out that our microcontroller program
outputted.

Our_traces_and_outputs
-Folder contains our test cases from our report and the output results.

ECE485_585_project_report.pdf
-This is our project report explaining what our program can do and all the test cases.

mem_controller.c
-Our final project code.  It asks for three things from the user.  First, it asks for
the input file name, then the output file name, then if you want debugging or not.
Debugging will just print printf statements tells you what was read from the trace file
and when something is inserted or removed from the queue.